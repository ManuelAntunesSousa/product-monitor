def send_email(site, url):
    print(f"[Email Sent] {site}: {url}")
